package org.gflogger.ring;

public interface Publishable {

	boolean isPublished();

	void setPublished(boolean published);
}
