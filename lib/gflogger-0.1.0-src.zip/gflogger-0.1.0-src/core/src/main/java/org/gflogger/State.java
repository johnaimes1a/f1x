package org.gflogger;

/**
 * @author vdolzhenko
 */
public enum State {
	NOT_STARTED,
	RUNNING,
	STOPPED
}
