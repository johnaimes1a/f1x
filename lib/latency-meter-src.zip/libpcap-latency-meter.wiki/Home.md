Start reading about LIBPCAP-LATENCY-METER [here](Overview).
