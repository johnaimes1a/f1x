General description of this tool can be found [here](Overview).

## Setup
* [Windows setup walk-through](Windows)
* [Linux setup walk-through](Windows)

## Run
### Live traffic monitoring

If your computer has multiple network adapters or VPN software, you need to obtain find out ID of network interface that you want to monitor. 

>NOTE: Due to specifics of Windows TCP/IP implementation WINPCAP cannot monitor loopback traffic (localhost).

Run bin/live-traffic script without any arguments.

    live-traffic

Script will display command line arguments help, followed by list of interfaces detected by LIBPCAP.

    Network devices found:
    #0: \Device\NPF_{0093D9BE-190D-4B59-BF8F-D9CE04004DBE} [Marvell Yukon Ethernet Controller.]
    #1: \Device\NPF_{BC81C4FC-242F-4F1C-9DAD-EA9523CC992D} [Intel(R) PRO/100 VE Network Connection]

Let's assume we want to capture network packets on Yukon network card from the above list (index #0). This interface can be selected using command line argument `-interface:0`.

### Example 1

Imagine we are measuring latency of FIX server that receives orders and immediately acknowledges them.
Server has FIX Acceptor on port 7777. Inbound messages (NewOrderSingle) are identified using FIX tag 11. Outbound messages (ExecutionReport) use the same tag to identify order they acknowledge. 

```
live-traffic.cmd -interface:0 -in:fix:11 -out:fix:11  "-filter:(tcp port 777)"
```

Utility is going to correlate inbound and outbound messages based on order ID (tag 11). By default utility assumes that direction of each packet can be determined relative to local IP address. We can also be more excplicit and specify this using -dir argument (direction relative to host 'sauron'):

```
live-traffic.cmd -interface:0 -in:fix:11 -out:fix:11  -dir:sauron "-filter:(tcp port 777)"
```


### Example 2

The following example shows how to capture FIX conversation with Integral FX-Inside FIX Server. Here we assume that the server offers two FIX connections: 1) Market Data Session is running on port 2508; 2) Trading Session is running on port 2509. We are going to parse inbound FIX market data and extract tag QuoteEntryID(299) from bids and asks of market data prices. For outbound traffic we are going parse outbound FIX messages and extract tag QuoteID(117) from trade orders. Utility is going to correlate inbound and outbound messages based on the quote IDs.

```
live-traffic.cmd -interface:0 -in:fix:299 -out:fix:117 -dir:2509:2508 "-filter:(tcp src port 2509) or (tcp dst port 2508)"
```
### Previously captured traffic processing

This tool can also process previously captured network traffic. For example you can setup your own capture using Wireshark or TCPDump and later process it via this tool. 


Command line syntax is similar

```
filed-traffic -pcap:./data/timebase.pcap  -in:fix:299 -out:fix:117 -dir:2509:2508
```

[Known limitations](Limitations)
 