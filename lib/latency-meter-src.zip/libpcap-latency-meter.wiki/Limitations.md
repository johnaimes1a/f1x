#Known limitations

* This tool cannot handle **large** messages. Tool does not re-assemble messages that were split between multiple TCP packets. We assume that your network's layer maximum packet size (MTU) is large enough to fit messages that you are capturing (Typically 1500 bytes). This should be true for most FIX traffic, with exception of SecurityDefinition(d) and MarketData-Snapshot/FullRefresh(W) messages containing many repeating groups. 

* This tool cannot process **SSL-encrypted traffic**. If your broker/market data provider requires SSL connection you can use [STUNNEL](https://www.stunnel.org) gateway to unwrap SSL encryption.