#Windows walk-through

The following steps describe how to use this tool on Linux. We used Centos 7.0 (x64).

>The following steps may require root privileges.

##Step 0: Get a copy 

    git clone https://github.com/andymalakov/libpcap-latency-meter.git

The following notes assume that you placed them into LATENCY_METER directory.

##Step 1: WINPCAP library

Download and install [winpcap](http://www.winpcap.org/). We tested with version 4.1.3.

##Step 2: jNetPcap (Java wrapper for LIBPCAP)

* Download [jNetPcap](http://jnetpcap.com/download). We tested with version 1.4.r1425. 
* Copy `jnetpcap.dll` and `jnetpcap-pcap100.dll` into LATENCY_METER/bin. 
* Copy `jnetpcap.jar` into LATENCY_METER/lib.

##Step 3: Build it
    ant build

##Step 4: Verify setup

Let's capture some network traffic. Build script includes `'hello'` target that displays network interfaces discovered by WINPCAP and captures first few packets from interface #0.

    ant hello
    hello:
     [java] Network devices found:
     [java] #0: \Device\NPF_{0093D9BE-190D-4B59-BF8F-D9CE04004DBE} [Marvell Yukon Ethernet Controller.]
     [java] #1: \Device\NPF_{BC81C4FC-242F-4F1C-9DAD-EA9523CC992D} [Intel(R) PRO/100 VE Network Connection]
     [java]
     [java] Choosing 'Marvell Yukon Ethernet Controller.' on your behalf:
     [java] Received packet at Thu Dec 04 16:15:36 EST 2014 caplen=107  len=107  ....
