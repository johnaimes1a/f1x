### What is it?
**LIBPCAP Latency Meter** is a small tool that measures time difference between inbound and outbound TCP packets messages.

### How does it work?
The tool intercepts inbound and outbound TCP packets containing your network messages. All captured packets carry time stamps. This tool matches outbound packets with corresponding inbound packets using some kind of correlation key (For example, value of specific FIX tags). 

![Signal latency](https://raw.github.com/andymalakov/libpcap-latency-meter/master/doc/signal-latency.png)

For example, this tool can be used measure latency of trading signals. FX market data feed usually contain a field [QuoteEntryID(299)](http://btobits.com/fixopaedia/fixdic44/tag_299_QuoteEntryID_.html), while FX orders may contain a field [QuoteID(117)](http://btobits.com/fixopaedia/fixdic42/tag_117_QuoteID_.html). Tool can correlate inbound and outbound messages based on the value provided in these tags.

![Tick-to-Quote packets correlation](https://raw.github.com/andymalakov/libpcap-latency-meter/master/doc/quote-to-order.png)

Simple statistics (min/max/avg) are printed out during run time and latency log of each signal is recorded into CSV file.

This tool can monitor latency of live network traffic or process previously captured traffic in pcap format (for example produced by [Wireshark](http://www.wireshark.org/)).

This tool is based on [jNetPcap](http://www.jnetpcap.com/) library, which is in turn is a wrapper around [libpcap](http://www.tcpdump.org/).

### Results
Tool prints brief stats during its run and records latency of every signal into binary file. Binary file can be later converted to CSV format. 

Additional utility produces percentile histograms from collected latencies (using HdrHistogram):

![Percentile chart](https://raw.github.com/andymalakov/libpcap-latency-meter/master/doc/latency-percentile.png)


###How precise is it?
Time stamps of each packet come from libpcap (WinPcap) library, which in turn gets them from the operating system kernel. WinPcap has [microsecond](http://msdn.microsoft.com/en-us/library/windows/hardware/ff553053%28v=vs.85%29.aspx) precision, while libpcap (Unix origin) has nanosecond precision.

###How to use it?

See [Quick Start wiki page](QuickStart).

### Limitations
* Current version does not handle TCP re-transmissions and duplicate packets. It is possible to implement protection against these exceptions using JNetPcap API, but currently this is out-of-scope.

* Current version doesn't re-assemble messages split between several TCP packets. jNetPcap has examples of doing that.

* Current version relies on strict order of inbound and outbound signals. 

* Any outbound signal must have corresponding inbound signal. Timestamps of inbound signals are stored in ring buffer. Outbound packet processor consumes ring buffer as it searches for matching signal.

###Disclaimer

This tool is provided "as is" without warranty of any kind and is to be used at your own risk. 

### License

This tool is distributed free of charge and royalties under [LGPL license](http://en.wikipedia.org/wiki/GNU_Lesser_General_Public_License)

Tool includes the following open source libraries:

* [jNetPcap](http://www.jnetpcap.com/) software developed by Sly Technologies.
* [HdrHistogram](http://hdrhistogram.github.io/HdrHistogram) from Gil Tene.
* [jUnit](http://junit.org/).

***
This tool has been tested with jNetPcap 1.4.r1425 with:
* Windows platform: Windows Server 2008 SR2, Windows 7 SP1 Pro (WinPcap 4.1.3)
* Linux platform: Centos 7.0 (LIBPCAP 1.5.3) and Fedora 19 (LIBPCAP 1.4.0)

