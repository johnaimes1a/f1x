#Linux walk-through

The following steps describe how to use this tool on Linux. We used Centos 7.0 (x64).

>The following steps may require root privileges.

##Step 0: Get a copy 

    git clone https://github.com/andymalakov/libpcap-latency-meter.git

Steps below assume this library resides in libpcap-latency-meter folder.

##Step 1: LIBPCAP library

Make sure libpcap is installed

    yum install libpcap

Our "Minimal" installation of CentOS came with __libpcap__ 1.5.3 pre-installed. Let's find out where it is (may be needed later):

    #find / -name '*libpcap*'

    /usr/lib64/libpcap.so.1
    /usr/lib64/libpcap.so.1.5.3
    /usr/share/doc/libpcap-1.5.3

##Step 2: jNetPcap (Java wrapper for LIBPCAP)

For CentOS we took RHEL5 x64 version of jNetPcap library from [http://jnetpcap.com/download]. Extract GZ and copy the following files into __libpcap-latency-meter/bin/__:

`jnetpcap.jar libjnetpcap-pcap100.so libjnetpcap.so`

Let's check 

    #ldd bin/libjnetpcap.so

If you see `libpcap.so.0.9.4 => not found`, you may need to define symbolic link:

    #ln -s /usr/lib64/libpcap.so.1  /usr/lib/libpcap.so.0.9.4

jNetPcap 1.4 is upward compatible with Libpcap 1.X.

##Step 3: Build it

    ant build

##Step 4: Verify setup

Let's capture some network traffic. Build script includes `'hello'` target that displays network interfaces discovered by LIBPCAP and captures first few packets from interface #0.

    ant hello
    hello:
	 [java] Network devices found:
	 [java] #0: lo [No description available]
	 [java] #1: any [Pseudo-device that captures on all interfaces]
	 [java] #2: enp3s0 [No description available]
	 [java] #3: enp2s0 [No description available]
	 [java] #4: usbmon1 [USB bus number 1]
	 [java] #5: nfqueue [Linux netfilter queue (NFQUEUE) interface]
	 [java] #6: nflog [Linux netfilter log (NFLOG) interface]
	 [java]
	 [java] Choosing 'lo' on your behalf:
	 [java] Received packet at Thu Dec 04 15:49:12 EST 2014 caplen=296  len=296 ...

In our case interface #0 is local loopback. Interfaces `enp2s0` and `enp3sp` are network cards:

    #nmcli connection show

    NAME    UUID                                  TYPE            DEVICE
    enp2s0  8f7b42ed-e26a-458e-b072-7b24129da9c7  802-3-ethernet  --
    enp3s0  33d09ea0-0c71-4bd6-a21f-16d30ba74d7c  802-3-ethernet  enp3s0

###Troubleshooting

Most errors are caused by missing LIBPCAP, try adding `/usr/lib` to library search path:

    export LD_LIBRARY_PATH=/usr/lib

If this doesn't help, we suggest looking into jNetPcap [release notes](http://sourceforge.net/p/jnetpcap/code/HEAD/tree/jnetpcap/trunk/doc/RELEASE_NOTES.txt).


   