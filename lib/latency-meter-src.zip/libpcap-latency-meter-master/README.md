libpcap-latency-meter
=================

Java-based tool to measure latency between inbound and outbound TCP packets (for example, FIX protocol messages).

See github wiki for more information.
